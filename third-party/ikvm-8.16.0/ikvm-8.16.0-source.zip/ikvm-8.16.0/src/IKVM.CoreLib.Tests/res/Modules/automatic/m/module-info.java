module m {
    requires alib;
}
