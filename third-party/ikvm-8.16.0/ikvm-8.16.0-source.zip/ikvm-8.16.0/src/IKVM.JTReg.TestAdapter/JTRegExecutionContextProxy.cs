﻿using System;
using System.Collections.Generic;

using IKVM.JTReg.TestAdapter.Core;

using Microsoft.VisualStudio.TestPlatform.ObjectModel;
using Microsoft.VisualStudio.TestPlatform.ObjectModel.Adapter;

namespace IKVM.JTReg.TestAdapter
{

    /// <summary>
    /// Proxies the <see cref="IJTRegExecutionContext"/> interface to the Visual Studio test adapter.
    /// </summary>
    class JTRegExecutionContextProxy : IJTRegExecutionContext
    {

        static readonly Dictionary<string, TestProperty> properties = new Dictionary<string, TestProperty>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        static JTRegExecutionContextProxy()
        {
            properties.Add(TestCaseProperties.FullyQualifiedName.Label, TestCaseProperties.FullyQualifiedName);
            properties.Add(TestCaseProperties.DisplayName.Label, TestCaseProperties.DisplayName);
            properties.Add(TestCaseProperties.ExecutorUri.Label, TestCaseProperties.ExecutorUri);
            properties.Add(TestCaseProperties.Source.Label, TestCaseProperties.Source);
            properties.Add(TestCaseProperties.CodeFilePath.Label, TestCaseProperties.CodeFilePath);
            properties.Add(JTRegTestProperties.TestSuiteRootProperty.Label, JTRegTestProperties.TestSuiteRootProperty);
            properties.Add(JTRegTestProperties.TestSuiteNameProperty.Label, JTRegTestProperties.TestSuiteNameProperty);
            properties.Add(JTRegTestProperties.TestPathNameProperty.Label, JTRegTestProperties.TestPathNameProperty);
            properties.Add(JTRegTestProperties.TestIdProperty.Label, JTRegTestProperties.TestIdProperty);
            properties.Add(JTRegTestProperties.TestTitleProperty.Label, JTRegTestProperties.TestTitleProperty);
            properties.Add(JTRegTestProperties.TestAuthorProperty.Label, JTRegTestProperties.TestAuthorProperty);
            properties.Add(JTRegTestProperties.TestPartitionProperty.Label, JTRegTestProperties.TestPartitionProperty);
            properties.Add(JTRegTestProperties.TestCategoryProperty.Label, JTRegTestProperties.TestCategoryProperty);
        }

        readonly IRunContext runContext;
        readonly IFrameworkHandle frameworkHandle;
        readonly ITestCaseFilterExpression filterExpression;

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <param name="runContext"></param>
        /// <param name="frameworkHandle"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public JTRegExecutionContextProxy(IRunContext runContext, IFrameworkHandle frameworkHandle)
        {
            this.runContext = runContext ?? throw new ArgumentNullException(nameof(runContext));
            this.frameworkHandle = frameworkHandle ?? throw new ArgumentNullException(nameof(frameworkHandle));
            this.filterExpression = runContext.GetTestCaseFilter(properties.Keys, s => properties.TryGetValue(s, out var v) ? v : null);

            Options = runContext.RunSettings.ToJTRegOptions();
        }

        public JTRegTestOptions Options { get; }

        public string TestRunDirectory => runContext.TestRunDirectory;

        public bool CanAttachDebuggerToProcess => frameworkHandle is IFrameworkHandle2;

        public bool AttachDebuggerToProcess(int pid)
        {
            return frameworkHandle is IFrameworkHandle2 h && h.AttachDebuggerToProcess(pid);
        }

        public bool FilterTestCase(JTRegTestCase test)
        {
            if (filterExpression == null)
                return true;

            var t = JTRegProxyUtil.Convert(test);
            return filterExpression.MatchTestCase(t, s => properties.TryGetValue(s, out var v) ? t.GetPropertyValue(v) : null);
        }

        public void RecordEnd(JTRegTestCase test, JTRegTestOutcome outcome)
        {
            frameworkHandle.RecordEnd(JTRegProxyUtil.Convert(test), JTRegProxyUtil.Convert(outcome));
        }

        public void RecordResult(JTRegTestResult rslt)
        {
            frameworkHandle.RecordResult(JTRegProxyUtil.Convert(rslt));
        }

        public void RecordStart(JTRegTestCase test)
        {
            frameworkHandle.RecordStart(JTRegProxyUtil.Convert(test));
        }

        public void SendMessage(JTRegTestMessageLevel level, string message)
        {
            frameworkHandle.SendMessage(JTRegProxyUtil.Convert(level), message);
        }

    }

}